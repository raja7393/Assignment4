package test;

public class DiceTest
{
	/*
	 * There is not really anything to test
	 * in Dice. The roll() method only calls DiceValue's
	 * getRandom, which we have tested already, the toString
	 * just calls its DiceValue's toString method (which is
	 * NOT the same as the toString written in DiceValue),
	 * and the others are just getters and setters. We
	 * will leave this class here in case there becomes
	 * something to test later.
	 */

}
