package replication;

public class Bug6Replication {

}
