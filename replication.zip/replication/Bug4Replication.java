package replication;

import game.Main;

public class Bug4Replication
{
	public static void main(String[] args) throws Exception
	{
		String[] argsTest = {"4"};
		Main.main(argsTest);
	}
}
