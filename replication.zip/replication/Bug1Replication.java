package replication;

public class Bug1Replication 
{

}
