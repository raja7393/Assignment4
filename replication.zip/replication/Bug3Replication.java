package replication;

public class Bug3Replication {

}
