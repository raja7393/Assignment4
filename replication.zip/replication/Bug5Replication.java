package replication;

public class Bug5Replication 
{

}
