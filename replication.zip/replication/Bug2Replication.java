package replication;

public class Bug2Replication {

}
